import React, { Fragment, useState } from "react";

const InputTask: React.FC = () => {
  const [description,setDescription] = useState("");
  const [title,setTitle] = useState("");

  const onSubmitForm = async(e: React.FormEvent) => {
    e.preventDefault();
    try {
      const body = { title, description };
      const response = await fetch("http://localhost:5000/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
  
      if (!response.ok) {
        throw new Error("Failed to add task");
      }
  
      console.log("Task added successfully");
      setTitle("");
      setDescription("");

      window.location.href = "/";
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <Fragment>
      <h1 className="text-center mt-5">Task management</h1>
      <form className="card p-4 shadow-lg mt-4" onSubmit={onSubmitForm}>
        <div className="mb-3">
          <label className="form-label fw-bold">Title</label>
          <input
            type="text"
            className="form-control"
            placeholder="Enter task title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label fw-bold">Description</label>
          <textarea
            className="form-control"
            placeholder="Enter task description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5} 
            required
          ></textarea>
        </div>
        <button className="btn btn-success">Add</button>
      </form>
    </Fragment>
  );
};

export default InputTask;