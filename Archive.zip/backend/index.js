const express = require("express");
const app = express();
const cors = require("cors");
const pool = require("./db");
require("dotenv").config();

app.use(cors());
app.use(express.json());

//Routes

//create task
app.post("/tasks", async (req, res) => {
  try {
    const { title, description } = req.body;
    const newTask = await pool.query(
      "INSERT INTO tasks (title, description, is_complete) VALUES ($1, $2, $3) RETURNING *",
      [title, description, false] // Default `is_complete` to false
    );
    res.json(newTask.rows[0]);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
});
//get all task
app.get("/tasks", async (req, res) => {
  try {
    const allTasks = await pool.query("SELECT * FROM tasks ORDER BY id ASC");
    res.json(allTasks.rows);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

//get a task
app.get("/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const task = await pool.query("SELECT * FROM tasks WHERE id = $1", [id]);
  
      if (task.rows.length === 0) {
        return res.status(404).json({ error: "Task not found" });
      }
  
      res.json(task.rows[0]);
    } catch (error) {
      console.error(error.message);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

//update
app.put("/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { title, description, is_complete } = req.body;
  
      const updatedTask = await pool.query(
        "UPDATE tasks SET title = $1, description = $2, is_complete = $3 WHERE id = $4 RETURNING *",
        [title, description, is_complete, id]
      );
  
      if (updatedTask.rows.length === 0) {
        return res.status(404).json({ error: "Task not found" });
      }
  
      res.json(updatedTask.rows[0]);
    } catch (error) {
      console.error(error.message);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

//delete
app.delete("/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deletedTask = await pool.query("DELETE FROM tasks WHERE id = $1 RETURNING *", [id]);
  
      if (deletedTask.rows.length === 0) {
        return res.status(404).json({ error: "Task not found" });
      }
  
      res.json({ message: "Task deleted successfully" });
    } catch (error) {
      console.error(error.message);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

app.listen(5000, () => {
  console.log("server started on 5000");
});
